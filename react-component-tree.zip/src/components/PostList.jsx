import PostItem from "./PostItem";

const PostList = (props) => (
  <div>
    {props.posts.map(post => (
      <PostItem key={post.id} post={post} />
    ))}
  </div>
);

export default PostList;