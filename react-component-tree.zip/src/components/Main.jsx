import Sidebar from "./Sidebar";
import Content from "./Content";

const Main = (props) => (
  <main style={{ display: "flex", padding: "20px" }}>
    <Sidebar />
    <Content posts={props.posts} />
  </main>
);

export default Main;