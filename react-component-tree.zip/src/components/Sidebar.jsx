const Sidebar = () => (
  <aside style={{ width: "200px", marginRight: "20px" }}>
    <h3>Категории</h3>
    <ul>
      <li>React</li>
      <li>JavaScript</li>
      <li>Frontend</li>
    </ul>
  </aside>
);

export default Sidebar;