const Header = () => (
  <header style={{ background: "#282c34", color: "white", padding: "15px" }}>
    <h1>My React Blog</h1>
  </header>
);

export default Header;