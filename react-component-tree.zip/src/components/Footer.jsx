const Footer = () => (
  <footer style={{ background: "#f1f1f1", padding: "10px", textAlign: "center" }}>
    <p>© 2026 My React Blog</p>
  </footer>
);

export default Footer;