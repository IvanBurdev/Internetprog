import PostList from "./PostList";

const Content = (props) => (
  <section style={{ flex: 1 }}>
    <h2>Публикации</h2>
    <PostList posts={props.posts} />
  </section>
);

export default Content;