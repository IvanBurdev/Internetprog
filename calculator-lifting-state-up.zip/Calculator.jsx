import React, { useMemo, useState } from "react";

// InputComponent: въвеждане на 2 числа + избор на операция
function InputComponent({
  a,
  b,
  operation,
  onChangeA,
  onChangeB,
  onChangeOperation,
}) {
  return (
    <div style={{ display: "grid", gap: 12, maxWidth: 320 }}>
      <label>
        Първо число:
        <input
          type="number"
          value={a}
          onChange={(e) => onChangeA(e.target.value)}
          style={{ width: "100%" }}
        />
      </label>

      <label>
        Второ число:
        <input
          type="number"
          value={b}
          onChange={(e) => onChangeB(e.target.value)}
          style={{ width: "100%" }}
        />
      </label>

      <label>
        Операция:
        <select
          value={operation}
          onChange={(e) => onChangeOperation(e.target.value)}
          style={{ width: "100%" }}
        >
          <option value="+">+</option>
          <option value="-">-</option>
          <option value="*">*</option>
          <option value="/">/</option>
        </select>
      </label>
    </div>
  );
}

// ResultComponent: показване на резултат или съобщение за грешка
function ResultComponent({ result, error }) {
  return (
    <div style={{ marginTop: 16 }}>
      <h3>Резултат:</h3>
      {error ? (
        <p style={{ color: "crimson" }}>{error}</p>
      ) : (
        <p style={{ fontSize: 18 }}>{result}</p>
      )}
    </div>
  );
}

// Parent: държи състоянието (lifting state up)
export default function Calculator() {
  const [a, setA] = useState("5");
  const [b, setB] = useState("5");
  const [operation, setOperation] = useState("+");

  const { result, error } = useMemo(() => {
    const numA = Number(a);
    const numB = Number(b);

    // невалидни/празни стойности
    if (a === "" || b === "" || Number.isNaN(numA) || Number.isNaN(numB)) {
      return { result: "-", error: "Моля, въведете валидни числа." };
    }

    if (operation === "/" && numB === 0) {
      return { result: "-", error: "Грешка: деление на 0 е невъзможно!" };
    }

    let r;
    switch (operation) {
      case "+":
        r = numA + numB;
        break;
      case "-":
        r = numA - numB;
        break;
      case "*":
        r = numA * numB;
        break;
      case "/":
        r = numA / numB;
        break;
      default:
        return { result: "-", error: "Непозната операция." };
    }

    return { result: r, error: "" };
  }, [a, b, operation]);

  return (
    <div style={{ fontFamily: "system-ui", padding: 16 }}>
      <h2>Калкулатор (Lifting State Up)</h2>

      <InputComponent
        a={a}
        b={b}
        operation={operation}
        onChangeA={setA}
        onChangeB={setB}
        onChangeOperation={setOperation}
      />

      <ResultComponent result={result} error={error} />
    </div>
  );
}
