# Калкулатор с Lifting State Up (React)

## Какво има вътре
- `Calculator.jsx` – родителски компонент, който държи state-а и изчислява резултата
- `InputComponent` – въвеждане на две числа + dropdown за операция
- `ResultComponent` – показва резултат или грешка (напр. деление на 0)

## Бързо пускане (пример с Vite)
1) Създай проект:
```bash
npm create vite@latest my-calculator -- --template react
cd my-calculator
npm install
```

2) Копирай файловете:
- сложи `Calculator.jsx` в `src/`
- замени `src/App.jsx` с предоставения `App.jsx`

3) Стартирай:
```bash
npm run dev
```
